package com.example.robotica.Model;

public class Robo {

	private String pecas;
	private String descricao;
	private String quantidade;
	private String nome;

	public String getPecas() {
		return pecas;
	}

	public void setPecas(String pecas) {
		this.pecas = pecas;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(String quantidade) {
		this.quantidade = quantidade;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}


}

