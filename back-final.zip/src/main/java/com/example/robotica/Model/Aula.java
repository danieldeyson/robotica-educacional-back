package com.example.robotica.Model;

public class Aula {

private String referencia;
private String conteudo;
private String assunto;
private String disciplina;
private String serie;
private String duracao;
private String recursoDidatico;
private String objetivo;
private String atividade;
private String nome;
private String programacao; 
private String robo;
private String descricao;
private String descricaoRobo;



	public String getProgramacao() {
		return programacao;
	}
	public void setProgramacao(String programacao) {
		this.programacao = programacao;
	}
	public String getRobo() {
		return robo;
	}
	public void setRobo(String robo) {
		this.robo = robo;
	}


public String getReferencia() {
    return referencia;
}

public void setReferencia(String referencia) {
    this.referencia = referencia;
}

public String getConteudo() {
    return conteudo;
}

public void setConteudo(String conteudo) {
    this.conteudo = conteudo;
}

public String getAssunto() {
    return assunto;
}

public void setAssunto(String assunto) {
    this.assunto = assunto;
}

public String getDisciplina() {
    return disciplina;
}

public void setDisciplina(String disciplina) {
    this.disciplina = disciplina;
}

public String getSerie() {
    return serie;
}

public void setSerie(String serie) {
    this.serie = serie;
}

public String getDuracao() {
    return duracao;
}

public void setDuracao(String duracao) {
    this.duracao = duracao;
}

public String getRecursoDidatico() {
    return recursoDidatico;
}

public void setRecursoDidatico(String recursoDidatico) {
    this.recursoDidatico = recursoDidatico;
}

public String getObjetivo() {
    return objetivo;
}

public void setObjetivo(String objetivo) {
    this.objetivo = objetivo;
}

public String getAtividade() {
    return atividade;
}

public void setAtividade(String atividade) {
    this.atividade = atividade;
}

public String getNome() {
    return nome;
}

public void setNome(String nome) {
    this.nome = nome;
}

public String getDescricao() {
    return descricao;
}

public void setDescricao(String descricao) {
    this.descricao = descricao;
}

public String getDescricaoRobo() {
    return descricaoRobo;
}

public void setDescricaoRobo(String descricaoRobo) {
    this.descricaoRobo = descricaoRobo;
}






}


