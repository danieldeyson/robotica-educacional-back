package com.example.robotica.Model;

public class Programacao {
    private String bloco;
    private String quantidadePecas;
    private String descript;
    private String atividade;
    private String tarefa;
    private String descTarefa;

    

    public String getBloco() {
        return bloco;
    }

    public void setBloco(String bloco) {
        this.bloco = bloco;
    }

    public String getQuantidadePecas() {
        return quantidadePecas;
    }

    public void setQuantidadePecas(String quantidadePecas) {
        this.quantidadePecas = quantidadePecas;
    }

    public String getDescript() {
        return descript;
    }

    public void setDescript(String descript) {
        this.descript = descript;
    }

    public String getAtividade() {
        return atividade;
    }

    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }

    public String getTarefa() {
        return tarefa;
    }

    public void setTarefa(String tarefa) {
        this.tarefa = tarefa;
    }

    public String getDescTarefa() {
        return descTarefa;
    }

    public void setDescTarefa(String descTarefa) {
        this.descTarefa = descTarefa;
    }
    
}