package com.example.robotica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoboticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
